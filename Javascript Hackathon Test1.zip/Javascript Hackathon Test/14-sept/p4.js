/*4.	What will be the output of the below Code? */
const array = [10, 20, 30, 40]; 

const result = array.map((num) => num / 2).filter((num) => num >= 15); 

console.log(result); 
/* output: [15,20] */
