/*6.	Analyze the below code. Do you see any issue? If Yes, What is that Issue? */

const object1 = { 
a: 10, 
b: 20, 
c: () => { 
console.log(object1.a + object1.b); // here use (this.a + this.b) output is NaN
}, 
}; 
const func = object1.c; 
func();
