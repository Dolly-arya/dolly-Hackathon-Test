/*
   7.	W.A.P JavaScript Logic to convert degree Celsius to Fahrenheit and Vice versa, 
       a.	accept the input as temperature
       b.	give a dropdown option to select conversion type for user
*/


// Function to convert Celsius to Fahrenheit
function celsiusToFahrenheit(celsius) {
    return (celsius * 9/5) + 32;
}

// Function to convert Fahrenheit to Celsius
function fahrenheitToCelsius(fahrenheit) {
    return (fahrenheit - 32) * 5/9;
}


function convertTemperature() {
    let temperature = document.getElementById('temperature').value;
    let conversionType = document.getElementById('conversionType').value;
    
    if(conversionType === 'celsiusToFahrenheit') {
        let result = celsiusToFahrenheit(temperature);
        alert(`${temperature}°C is equal to ${result}°F`);
    } else if(conversionType === 'fahrenheitToCelsius') {
        let result = fahrenheitToCelsius(temperature);
        alert(`${temperature}°F is equal to ${result}°C`);
    }
}


