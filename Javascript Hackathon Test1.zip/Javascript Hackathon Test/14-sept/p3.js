/*3.	W.A.P Given an array of all your Wishlist items, figure out how much it would cost to just buy everything at once*/
function shoppingSpree(arr) {
   // your code here 
   let total = 0;
    for (let i = 0; i < arr.length; i++) {
        total += arr[i].price;
    }
    return total;
   
}
 
var wishlist = [
    { title: "Tesla Model S", price: 90000 },
    { title: "4 carat diamond ring", price: 45000 },
    { title: "Fancy hacky Sack", price: 5 },
    { title: "Gold fidgit spinner", price: 2000 },
    { title: "A second Tesla Model S", price: 90000 }
];
 
console.log(shoppingSpree(wishlist)); // 227005








