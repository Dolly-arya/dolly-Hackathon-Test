/*2.	W.A.P Given An array of array’s, flatten them into single Array?*/
function flatten(arr) {
   // your code here
   //return arr.reduce((acc, val) => acc.concat(Array.isArray(val)? flatten(val) : val), []);
   let result = [];
    for (let i = 0; i < arr.length; i++) {
        if (Array.isArray(arr[i])) {
            result = result.concat(flatten(arr[i]));
        } else {
            result.push(arr[i]);
        }
    }
    return result;


}
 
var arrays = [
    ["1", "2", "3"],
    [true],
    [4, 5, 6]
];
 
console.log(flatten(arrays)); // ["1", "2", "3", true, 4, 5, 6];
