/*9.	W.A.P to implement a simple shopping cart system with features to add items, remove items and calculate the total price. Use objects to represent items, including properties for the item name, price and quantity. Implement features to add items to the cart, remove items and calculate the total cost. 
a.	Use the below api https://dummyjson.com/products	
b.	You can use the local storage 
c.	Use Promise Constructor to fetch the data from api link*/
