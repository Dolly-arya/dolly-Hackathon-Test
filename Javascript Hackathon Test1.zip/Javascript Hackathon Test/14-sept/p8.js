/*8.	Create a JavaScript function that calculates the tip for a given bill amount and tip percentage. Bill amount and tip percentage will be input parameters while output will be calculated tip value.*/

function calculateTip(billAmount, tipPercentage) {
    // Your code here
    //return billAmount * (tipPercentage / 100);
    // Example: calculateTip(100, 15); // Output: 15
    if (billAmount <= 0 || tipPercentage <= 0) {
        return "Invalid input. Please enter a positive number for both bill amount and tip percentage.";
    } else {
        let tip = (billAmount * tipPercentage) / 100;
        return tip;
    }


}

console.log(calculateTip(100, 15)); // Output: 15



