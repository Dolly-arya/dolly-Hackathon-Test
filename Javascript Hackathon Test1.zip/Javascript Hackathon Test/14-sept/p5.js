/*5.	Debug the error in the below given Code?*/

let counter = 0; 
for (var i = 1; i <=10; i++) { 
counter+= i; // 45+10
if (i === 10) {
    console.log(i);//10
}
}
 	console.log(counter); // 55
     //console.log(i); // 11

